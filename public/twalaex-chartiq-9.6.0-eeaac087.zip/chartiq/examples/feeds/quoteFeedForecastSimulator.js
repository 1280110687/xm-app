// -------------------------------------------------------------------------------------------
// Copyright © 2023 S&P Global All rights reserved
// -------------------------------------------------------------------------------------------
// SAMPLE QUOTEFEED IMPLEMENTATION -- Generates randomized forecast data
///////////////////////////////////////////////////////////////////////////////////////////////////////////
import { CIQ } from "../../js/chartiq.js";
/**
 * @module ./quoteFeedForecastSimulator
 * @timport { CIQ } from "../../js/chartiq.js";
 * @texport default quoteFeedForecastSimulator
 */
/**
 * @typedef QuoteFeedForecastSimulatorType
 * @property {Date} DT
 * @property {number} Close
 * @property {number} High
 * @property {number} Low
 * @property {number} Open
 * @property {number} Volume
 */
/**
 *
 * @name quoteFeedForecastSimulator
 * @namespace
 */
var quoteFeedForecastSimulator = {}; // the quotefeed object
// Some default constants which the simulator works with, they can be overridden
/**
 * valid symbols
 *
 * @type {string[]}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.valids = ["FOR", "FF", "FTFT", "AIQ", "EURCHF"];
/**
 * where the forecast begins
 *
 * @type {number}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.periodsBack = 50;
/**
 * where the forecast ends
 *
 * @type {number}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.periodsForward = 50;
/**
 * how widely the close will fluctuate in the forecast
 *
 * @type {number}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.randomizationFactor = 0.3;
/**
 * how quickly the high/low spread will be allowed to grow as the forecast progresses
 *
 * @type {number}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.spreadPercentage = 0.05;
/**
 * these add up to 100% and help predict the Certainty matrix which can be plotted on a scatterplot.
 *
 * @type {number[]}
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.certaintyPercentages = [
	0.35, 0.15, 0.08, 0.05, 0.02, 0.01, 0.01
];
// each of these certainty percentages will get a price attached to it by the simulator
/**
 * Creates the forecast.  In the real world this function is replaced by a call to a remote server which contains the forecast data.
 * In this implementation the entire series is returned in one response
 *
 * @param {CIQ.ChartEngine} stx Chart engine
 * @param {string} symbol Forecast symbol
 * @param {string} interval Current quote interval
 * @param {number} period Current quote period
 * @return {null | undefined | QuoteFeedForecastSimulatorType[]} Forecasted quote records
 *
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.generateData = function (
	stx,
	symbol,
	interval,
	period
) {
	if (!stx.chart.masterData || !stx.chart.masterData.length) return;
	if (quoteFeedForecastSimulator.valids.indexOf(symbol) == -1) return null; // no data for any symbol outside of defined set
	var endPoints, isSeries;
	if (symbol == stx.chart.symbol) endPoints = stx.chart.endPoints;
	else {
		for (var series in stx.chart.series) {
			if (symbol == stx.chart.series[series].parameters.symbol) {
				isSeries = true;
				endPoints = stx.chart.series[symbol].endPoints;
			}
		}
	}
	if (!endPoints) return;
	var iter_parms = {
		begin: endPoints.end,
		interval: interval,
		periodicity: period
	};
	var market = new CIQ.Market(CIQ.Market.Symbology.factory({ symbol: symbol }));
	var iterator = market.newIterator(iter_parms);
	iterator.previous(
		quoteFeedForecastSimulator.periodsBack * stx.layout.periodicity
	);
	// look for first record before iterator point that has data
	var startTick;
	for (
		startTick = stx.chart.masterData.length - 1;
		startTick >= 0;
		startTick--
	) {
		if (stx.chart.masterData[startTick].DT <= iterator.begin) break;
	}
	if (startTick < 0) startTick = 0;
	var originalStartValue = stx.chart.masterData[startTick],
		startValue,
		startDate,
		startVolume;
	while (startTick < stx.chart.masterData.length) {
		startValue = stx.chart.masterData[startTick];
		startDate = startValue.DT;
		startVolume = startValue.Volume;
		if (startValue) {
			if (isSeries) startValue = startValue[symbol];
			if (startValue) {
				if (typeof startValue == "object") {
					startVolume = startValue.Volume;
					startValue = startValue.Close;
				}
				if (startValue || startValue === 0) break;
			}
		}
		startTick++;
	}
	if (!startValue && startValue !== 0) {
		startValue = originalStartValue.Close;
		startDate = originalStartValue.DT;
		startVolume = originalStartValue.Volume;
	}
	var factor = quoteFeedForecastSimulator.randomizationFactor,
		decimalPlaces = 2;
	if (Math.abs(startValue) < 2) {
		decimalPlaces = 4;
		factor /= 100;
	}
	var pushData = [];
	var totalPeriods =
		(quoteFeedForecastSimulator.periodsBack +
			quoteFeedForecastSimulator.periodsForward) *
		stx.layout.periodicity;
	while (pushData.length < totalPeriods) {
		var lastForecast = pushData[pushData.length - 1];
		var record;
		if (lastForecast) {
			record = {
				DT: iterator.next(),
				Close: Number(
					((CIQ.random() - 0.5) * factor + lastForecast.Close).toFixed(
						decimalPlaces
					)
				),
				Open: Number(lastForecast.Close),
				Volume: lastForecast.Volume * (1 + (CIQ.random() - 0.5) / 10),
				Certainty: []
			};
			record.High =
				record.Close *
				(1 +
					(quoteFeedForecastSimulator.spreadPercentage * pushData.length) /
						totalPeriods);
			record.Low =
				record.Close *
				(1 -
					(quoteFeedForecastSimulator.spreadPercentage * pushData.length) /
						totalPeriods);
			var certaintyPercentageLength =
				quoteFeedForecastSimulator.certaintyPercentages.length;
			for (var cp = 0; cp < certaintyPercentageLength; cp++) {
				var v = quoteFeedForecastSimulator.certaintyPercentages[cp];
				if (!cp) record.Certainty.push([record.Close, null, v]);
				else {
					record.Certainty.push([
						record.Close +
							(cp / (certaintyPercentageLength - 1)) *
								(record.High - record.Close),
						null,
						v
					]);
					record.Certainty.push([
						record.Close +
							(cp / (certaintyPercentageLength - 1)) *
								(record.Low - record.Close),
						null,
						v
					]);
				}
			}
		} else {
			record = {
				DT: startDate,
				Close: startValue,
				High: startValue,
				Low: startValue,
				Open: startValue,
				Volume: startVolume
			};
			iter_parms.begin = startDate;
			iterator = market.newIterator(iter_parms);
		}
		pushData.push(record);
	}
	return pushData;
};
/**
 * called by chart to fetch initial data.  This implementation returns all the existing data at once, so moreAvailable is set to false.
 *
 * @param {string} symbol Forecast symbol
 * @param {Date} suggestedStartDate Start time
 * @param {Date} suggestedEndDate End time
 * @param {object} params Other useful parameters
 * @param {CIQ.ChartEngine} params.stx Chart engine
 * @param {string} params.interval Current quote interval
 * @param {number} params.period Current quote period
 * @param {function} cb Callback function
 *
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.fetchInitialData = function (
	symbol,
	suggestedStartDate,
	suggestedEndDate,
	params,
	cb
) {
	var quotes = quoteFeedForecastSimulator.generateData(
		params.stx,
		symbol,
		params.interval,
		params.period
	);
	if (!quotes) cb({ error: "Not found" });
	else
		cb({
			quotes: quotes,
			moreAvailable: false,
			attribution: { source: "forecaster", exchange: "RANDOM" }
		});
};
/**
 * called by chart to fetch update data
 *
 * @param {string} symbol Forecast symbol
 * @param {Date} startDate Start time
 * @param {object} params Other useful parameters
 * @param {CIQ.ChartEngine} params.stx Chart engine
 * @param {string} params.interval Current quote interval
 * @param {number} params.period Current quote period
 * @param {function} cb Callback function
 *
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.fetchUpdateData = function (
	symbol,
	startDate,
	params,
	cb
) {
	var quotes = quoteFeedForecastSimulator.generateData(
		params.stx,
		symbol,
		params.interval,
		params.period
	);
	if (!quotes) cb({ error: "Not found" });
	else
		cb({
			quotes: quotes,
			moreAvailable: false,
			attribution: { source: "forecaster", exchange: "RANDOM" }
		});
};
/**
 * called by chart to fetch pagination data.  Shouldn't be called since the initial request set moreAvailable to false.
 *
 * @param {string} symbol Forecast symbol
 * @param {Date} suggestedStartDate Start time
 * @param {Date} endDate End time
 * @param {object} params Other useful parameters
 * @param {CIQ.ChartEngine} params.stx Chart engine
 * @param {string} params.interval Current quote interval
 * @param {number} params.period Current quote period
 * @param {function} cb Callback function
 *
 * @memberof quoteFeedForecastSimulator
 */
quoteFeedForecastSimulator.fetchPaginationData = function (
	symbol,
	suggestedStartDate,
	endDate,
	params,
	cb
) {
	var quotes = quoteFeedForecastSimulator.generateData(
		params.stx,
		symbol,
		params.interval,
		params.period
	);
	if (!quotes) cb({ error: "Not found" });
	else
		cb({
			quotes: quotes,
			moreAvailable: false,
			attribution: { source: "forecaster", exchange: "RANDOM" }
		});
};
export default quoteFeedForecastSimulator;
