/**
 *
 * Modifies top-level ChartIQ object with license-related objects and methods.
 *
 * @param CIQ Top-level ChartIQ namespace
 * @param CIQ CIQ namespace
 */
export default function getLicenseKey(CIQ: object): void;


